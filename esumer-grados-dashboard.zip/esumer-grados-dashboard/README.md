# 🎓 Dashboard Grados ESUMER — Abril 2026-1

Dashboard interactivo en tiempo real para monitorear inscripciones a ceremonia de grados de la Institución Universitaria ESUMER.

## ✨ Features

- **Conexión en tiempo real** con Google Sheets vía Apps Script API
- **Auto-refresh** cada 30 segundos
- **4 vistas**: General, Pipeline de Requisitos, Demografía, Tendencia
- **5 KPIs**: Total inscritos, completitud, programas, empleabilidad
- **Pipeline visual** de 8 requisitos de grado con barras de progreso
- **Dark/Light mode** toggle
- **Animaciones** de entrada, hover y conteo numérico
- **Responsive** para desktop y tablet

## 🚀 Deploy en Vercel

### 1. Subir a GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/TU_USUARIO/esumer-grados-dashboard.git
git push -u origin main
```

### 2. Deploy en Vercel
1. Ve a [vercel.com](https://vercel.com) → New Project
2. Importa tu repo de GitHub
3. Framework: **Vite** (auto-detectado)
4. Click **Deploy**

### 3. Google Apps Script (ya configurado)
La URL de la API ya está integrada en `src/App.jsx`.
Si necesitas cambiarla, edita la constante `API_URL` al inicio del archivo.

## 🛠️ Desarrollo local

```bash
npm install
npm run dev
```

Abre `http://localhost:5173`

## 📊 Stack

- React 18 + Vite 5
- Recharts (gráficas)
- Google Apps Script (API de datos)
- Vercel (hosting)
